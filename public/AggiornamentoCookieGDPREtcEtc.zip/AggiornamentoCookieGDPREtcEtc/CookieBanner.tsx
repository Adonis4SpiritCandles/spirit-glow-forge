import { useEffect, useState } from "react";

// Types for consent categories and services
interface Service {
  key: string;
  name: string;
  description: string;
  link: string;
  provider: string;
}

interface Category {
  key: string;
  name: string;
  description: string;
  services: Service[];
  // Strictly necessary cookies cannot be disabled
  required?: boolean;
}

// Translation strings for English and Polish
const translations = {
  en: {
    title: "We respect your privacy",
    intro:
      "We use cookies to enhance your experience, analyse site traffic and deliver personalised marketing.",
    manage: "Manage preferences",
    acceptAll: "Accept all",
    rejectAll: "Reject all",
    save: "Save preferences",
    categories: {
      necessary: {
        name: "Strictly necessary",
        description:
          "Essential for the operation of the site, such as security, authentication and payment.",
      },
      functional: {
        name: "Functional",
        description:
          "Enable enhanced features and remember your preferences.",
      },
      analytics: {
        name: "Analytics",
        description:
          "Collect anonymised information to help us understand how the site is used.",
      },
      marketing: {
        name: "Marketing",
        description:
          "Track browsing to deliver personalised ads and measure campaigns.",
      },
      social: {
        name: "Social media",
        description:
          "Allow you to interact with embedded content and share on social platforms.",
      },
    },
    services: {
      supabase: {
        name: "Supabase",
        description: "Keeps you logged in and manages your session.",
      },
      stripe: {
        name: "Stripe",
        description: "Processes payments securely and prevents fraud.",
      },
      furgonetka: {
        name: "Furgonetka",
        description:
          "Lets you choose shipping methods and track your parcel.",
      },
      resend: {
        name: "Resend",
        description: "Sends transactional emails such as order confirmations.",
      },
      ga4: {
        name: "Google Analytics 4",
        description:
          "Helps us analyse website traffic and improve our services.",
      },
      metaPixel: {
        name: "Meta Pixel",
        description: "Tracks conversions and enables targeted advertising.",
      },
      youtube: {
        name: "YouTube",
        description: "Embeds videos and stores your preferences.",
      },
      tiktok: {
        name: "TikTok Pixel",
        description: "Measures ad performance and builds custom audiences on TikTok.",
      },
      twitter: {
        name: "Twitter Pixel",
        description: "Tracks conversions from Twitter ads and personalises advertising.",
      },
    },
  },
  pl: {
    title: "Szanujemy Twoją prywatność",
    intro:
      "Używamy plików cookie, aby poprawić korzystanie z serwisu, analizować ruch i wyświetlać spersonalizowane reklamy.",
    manage: "Zarządzaj preferencjami",
    acceptAll: "Akceptuj wszystkie",
    rejectAll: "Odrzuć wszystkie",
    save: "Zapisz ustawienia",
    categories: {
      necessary: {
        name: "Niezbędne",
        description:
          "Niezbędne do działania strony, np. bezpieczeństwo, logowanie i płatności.",
      },
      functional: {
        name: "Funkcjonalne",
        description:
          "Umożliwiają dodatkowe funkcje i zapamiętują Twoje ustawienia.",
      },
      analytics: {
        name: "Analityczne",
        description:
          "Zbierają anonimowe informacje, aby pomóc nam zrozumieć korzystanie ze strony.",
      },
      marketing: {
        name: "Marketingowe",
        description:
          "Śledzą przeglądanie w celu wyświetlania spersonalizowanych reklam.",
      },
      social: {
        name: "Media społecznościowe",
        description:
          "Umożliwiają interakcję z osadzonymi treściami i udostępnianie w mediach społecznościowych.",
      },
    },
    services: {
      supabase: {
        name: "Supabase",
        description: "Utrzymuje Twoją sesję i logowanie.",
      },
      stripe: {
        name: "Stripe",
        description: "Przetwarza płatności i zapobiega oszustwom.",
      },
      furgonetka: {
        name: "Furgonetka",
        description: "Pozwala wybrać metodę dostawy i śledzić paczkę.",
      },
      resend: {
        name: "Resend",
        description: "Wysyła wiadomości e‑mail, np. potwierdzenia zamówień.",
      },
      ga4: {
        name: "Google Analytics 4",
        description:
          "Pomaga analizować ruch na stronie i ulepszać nasze usługi.",
      },
      metaPixel: {
        name: "Piksel Meta",
        description:
          "Śledzi konwersje i umożliwia spersonalizowaną reklamę.",
      },
      youtube: {
        name: "YouTube",
        description: "Odtwarza filmy i zapisuje Twoje preferencje.",
      },
      tiktok: {
        name: "Piksel TikTok",
        description: "Mierzy skuteczność reklam i tworzy grupy odbiorców na TikToku.",
      },
      twitter: {
        name: "Piksel Twitter",
        description: "Śledzi konwersje z reklam Twittera i personalizuje reklamy.",
      },
    },
  },
} as const;

// Define categories with services; these will be translated at render time
const categories: Category[] = [
  {
    key: "necessary",
    name: "necessary",
    description: "",
    services: [
      {
        key: "supabase",
        name: "supabase",
        description: "",
        link: "https://supabase.com/privacy",
        provider: "Supabase Inc.",
      },
      {
        key: "stripe",
        name: "stripe",
        description: "",
        link: "https://stripe.com/privacy",
        provider: "Stripe, Inc.",
      },
    ],
    required: true,
  },
  {
    key: "functional",
    name: "functional",
    description: "",
    services: [
      {
        key: "furgonetka",
        name: "furgonetka",
        description: "",
        link: "https://furgonetka.pl/en/privacy",
        provider: "Furgonetka sp. z o.o.",
      },
      {
        key: "resend",
        name: "resend",
        description: "",
        link: "https://resend.com/privacy",
        provider: "Resend, Inc.",
      },
    ],
  },
  {
    key: "analytics",
    name: "analytics",
    description: "",
    services: [
      {
        key: "ga4",
        name: "ga4",
        description: "",
        link: "https://policies.google.com/privacy",
        provider: "Google LLC",
      },
    ],
  },
  {
    key: "marketing",
    name: "marketing",
    description: "",
    services: [
      {
        key: "metaPixel",
        name: "metaPixel",
        description: "",
        link: "https://www.facebook.com/privacy/policy",
        provider: "Meta Platforms Ireland Ltd.",
      },
      {
        key: "tiktok",
        name: "tiktok",
        description: "",
        link: "https://www.tiktok.com/legal/privacy-policy?lang=en",
        provider: "TikTok Technology Limited",
      },
      {
        key: "twitter",
        name: "twitter",
        description: "",
        link: "https://twitter.com/en/privacy",
        provider: "Twitter International Unlimited Company",
      },
    ],
  },
  {
    key: "social",
    name: "social",
    description: "",
    services: [
      {
        key: "youtube",
        name: "youtube",
        description: "",
        link: "https://policies.google.com/privacy",
        provider: "Google LLC",
      },
    ],
  },
];

// Local storage key
const STORAGE_KEY = "cookie_consent_v2";

interface ConsentState {
  // category-level decisions
  [key: string]: boolean;
}

export default function CookieBanner() {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [consent, setConsent] = useState<ConsentState>({});
  const [lang, setLang] = useState<'en' | 'pl'>('en');

  // Load language from navigator or html lang
  useEffect(() => {
    const htmlLang = document.documentElement.lang;
    if (htmlLang && (htmlLang.startsWith('pl') || htmlLang.startsWith('en'))) {
      setLang(htmlLang.startsWith('pl') ? 'pl' : 'en');
    } else {
      const navLang = navigator.language || navigator.languages[0];
      if (navLang && navLang.startsWith('pl')) setLang('pl');
    }
  }, []);

  // Load saved consent from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed: ConsentState = JSON.parse(stored);
        setConsent(parsed);
        setOpen(false);
      } else {
        setOpen(true);
      }
    } catch (err) {
      // If parsing fails, show banner again
      setOpen(true);
    }
  }, []);

  // Update consent and apply to analytics/marketing providers
  const updateConsent = (newConsent: ConsentState) => {
    setConsent(newConsent);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newConsent));
    // Update Google Consent Mode if available
    if (typeof window !== 'undefined' && (window as any).gtag) {
      const analyticsGranted = newConsent.analytics ? 'granted' : 'denied';
      // Grant ad storage if marketing or social cookies are accepted
      const adGranted = newConsent.marketing || newConsent.social ? 'granted' : 'denied';
      (window as any).gtag('consent', 'update', {
        analytics_storage: analyticsGranted,
        ad_storage: adGranted,
      });
    }
  };

  const handleAcceptAll = () => {
    const all: ConsentState = {};
    categories.forEach((cat) => {
      all[cat.key] = true;
    });
    updateConsent(all);
    setOpen(false);
  };

  const handleRejectAll = () => {
    const all: ConsentState = {};
    categories.forEach((cat) => {
      all[cat.key] = cat.required ? true : false;
    });
    updateConsent(all);
    setOpen(false);
  };

  const handleSave = () => {
    updateConsent(consent);
    setOpen(false);
  };

  const toggleCategory = (key: string) => {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  if (!open) return null;

  const t = translations[lang];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center p-4 bg-black bg-opacity-50"
      style={{ backdropFilter: 'blur(2px)' }}
    >
      <div className="bg-white w-full max-w-xl rounded-lg shadow-lg p-6 overflow-y-auto max-h-screen">
        <h2 className="text-xl font-semibold mb-2">{t.title}</h2>
        <p className="mb-4 text-sm text-gray-700">{t.intro}</p>
        <div className="space-y-3">
          {categories.map((cat) => {
            const catTrans = t.categories[cat.key as keyof typeof t.categories];
            const isOpen = expanded[cat.key];
            const checked = consent[cat.key] ?? cat.required ?? false;
            return (
              <div key={cat.key} className="border rounded">
                <div
                  className="flex items-center justify-between p-3 cursor-pointer"
                  onClick={() => toggleCategory(cat.key)}
                >
                  <div>
                    <h3 className="font-semibold">{catTrans.name}</h3>
                    <p className="text-xs text-gray-600">{catTrans.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {!cat.required && (
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e) => {
                          const value = e.target.checked;
                          const updated = { ...consent, [cat.key]: value };
                          // if category unchecked, also uncheck services
                          updateConsent(updated);
                        }}
                        className="h-4 w-4"
                      />
                    )}
                    {cat.required && (
                      <span className="text-xs text-gray-500">{lang === 'pl' ? 'Zawsze aktywne' : 'Always on'}</span>
                    )}
                    <button
                      type="button"
                      className="text-gray-500 focus:outline-none"
                      aria-label="Toggle details"
                    >
                      {isOpen ? '−' : '+'}
                    </button>
                  </div>
                </div>
                {isOpen && (
                  <div className="px-4 pb-4 text-sm text-gray-700 space-y-3">
                    {cat.services.map((svc) => {
                      const svcTrans = t.services[svc.key as keyof typeof t.services];
                      const svcChecked = consent[cat.key] ?? cat.required ?? false;
                      return (
                        <div key={svc.key} className="flex items-start justify-between">
                          <div>
                            <p className="font-medium">{svcTrans.name}</p>
                            <p className="text-xs text-gray-600">
                              {svcTrans.description}{' '}
                              <a
                                href={svc.link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="underline"
                              >
                                {lang === 'pl' ? 'Dowiedz się więcej' : 'Learn more'}
                              </a>
                            </p>
                          </div>
                          {!cat.required && (
                            <input
                              type="checkbox"
                              checked={svcChecked}
                              onChange={(e) => {
                                // toggling a service toggles the whole category
                                const value = e.target.checked;
                                const updated = { ...consent, [cat.key]: value };
                                updateConsent(updated);
                              }}
                              className="h-4 w-4 mt-1"
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-4 flex flex-col sm:flex-row gap-2">
          <button
            onClick={handleRejectAll}
            className="w-full sm:w-auto px-4 py-2 border border-gray-300 rounded bg-gray-100 hover:bg-gray-200"
          >
            {t.rejectAll}
          </button>
          <button
            onClick={handleAcceptAll}
            className="w-full sm:w-auto px-4 py-2 rounded text-white bg-gray-800 hover:bg-gray-700"
          >
            {t.acceptAll}
          </button>
          <button
            onClick={handleSave}
            className="w-full sm:w-auto px-4 py-2 border border-gray-300 rounded bg-gray-100 hover:bg-gray-200"
          >
            {t.save}
          </button>
        </div>
      </div>
    </div>
  );
}